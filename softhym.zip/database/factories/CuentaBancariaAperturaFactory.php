<?php

namespace Database\Factories;

use App\Models\CuentaBancariaApertura;
use Illuminate\Database\Eloquent\Factories\Factory;

class CuentaBancariaAperturaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CuentaBancariaApertura::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
