<?php

namespace Database\Factories;

use App\Models\PerfilPermiso;
use Illuminate\Database\Eloquent\Factories\Factory;

class PerfilPermisoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = PerfilPermiso::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
