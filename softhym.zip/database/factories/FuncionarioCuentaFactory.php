<?php

namespace Database\Factories;

use App\Models\FuncionarioCuenta;
use Illuminate\Database\Eloquent\Factories\Factory;

class FuncionarioCuentaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = FuncionarioCuenta::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
