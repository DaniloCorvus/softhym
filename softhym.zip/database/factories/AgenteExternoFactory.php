<?php

namespace Database\Factories;

use App\Models\AgenteExterno;
use Illuminate\Database\Eloquent\Factories\Factory;

class AgenteExternoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = AgenteExterno::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
