<?php

namespace Database\Factories;

use App\Models\FuncionarioReferencia;
use Illuminate\Database\Eloquent\Factories\Factory;

class FuncionarioReferenciaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = FuncionarioReferencia::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
