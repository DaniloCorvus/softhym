<?php

namespace Database\Factories;

use App\Models\CuentaBancariaCierre;
use Illuminate\Database\Eloquent\Factories\Factory;

class CuentaBancariaCierreFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CuentaBancariaCierre::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
