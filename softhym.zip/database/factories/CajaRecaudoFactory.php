<?php

namespace Database\Factories;

use App\Models\CajaRecaudo;
use Illuminate\Database\Eloquent\Factories\Factory;

class CajaRecaudoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CajaRecaudo::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
