<?php

namespace Database\Factories;

use App\Models\ConsultorApertura;
use Illuminate\Database\Eloquent\Factories\Factory;

class ConsultorAperturaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ConsultorApertura::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
