<?php

namespace Database\Factories;

use App\Models\BolsaBolivares;
use Illuminate\Database\Eloquent\Factories\Factory;

class BolsaBolivaresFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = BolsaBolivares::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
