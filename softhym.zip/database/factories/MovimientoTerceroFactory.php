<?php

namespace Database\Factories;

use App\Models\MovimientoTercero;
use Illuminate\Database\Eloquent\Factories\Factory;

class MovimientoTerceroFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = MovimientoTercero::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
