<?php

namespace Database\Factories;

use App\Models\DevolucionCompra;
use Illuminate\Database\Eloquent\Factories\Factory;

class DevolucionCompraFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = DevolucionCompra::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
