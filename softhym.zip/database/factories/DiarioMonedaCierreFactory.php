<?php

namespace Database\Factories;

use App\Models\DiarioMonedaCierre;
use Illuminate\Database\Eloquent\Factories\Factory;

class DiarioMonedaCierreFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = DiarioMonedaCierre::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
