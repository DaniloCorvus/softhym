<?php

namespace Database\Factories;

use App\Models\CorresponsalDiario;
use Illuminate\Database\Eloquent\Factories\Factory;

class CorresponsalDiarioFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CorresponsalDiario::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
