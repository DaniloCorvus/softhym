<?php

namespace Database\Factories;

use App\Models\GiroRemitente;
use Illuminate\Database\Eloquent\Factories\Factory;

class GiroRemitenteFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = GiroRemitente::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
