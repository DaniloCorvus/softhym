<?php

namespace App\Http\Controllers;

use App\Models\DocumentoExtranjero;
use Illuminate\Http\Request;

class DocumentoExtranjeroController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DocumentoExtranjero  $documentoExtranjero
     * @return \Illuminate\Http\Response
     */
    public function show(DocumentoExtranjero $documentoExtranjero)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DocumentoExtranjero  $documentoExtranjero
     * @return \Illuminate\Http\Response
     */
    public function edit(DocumentoExtranjero $documentoExtranjero)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DocumentoExtranjero  $documentoExtranjero
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DocumentoExtranjero $documentoExtranjero)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DocumentoExtranjero  $documentoExtranjero
     * @return \Illuminate\Http\Response
     */
    public function destroy(DocumentoExtranjero $documentoExtranjero)
    {
        //
    }
}
