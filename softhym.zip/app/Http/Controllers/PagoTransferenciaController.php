<?php

namespace App\Http\Controllers;

use App\Models\PagoTransferencia;
use Illuminate\Http\Request;

class PagoTransferenciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PagoTransferencia  $pagoTransferencia
     * @return \Illuminate\Http\Response
     */
    public function show(PagoTransferencia $pagoTransferencia)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PagoTransferencia  $pagoTransferencia
     * @return \Illuminate\Http\Response
     */
    public function edit(PagoTransferencia $pagoTransferencia)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PagoTransferencia  $pagoTransferencia
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PagoTransferencia $pagoTransferencia)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PagoTransferencia  $pagoTransferencia
     * @return \Illuminate\Http\Response
     */
    public function destroy(PagoTransferencia $pagoTransferencia)
    {
        //
    }
}
