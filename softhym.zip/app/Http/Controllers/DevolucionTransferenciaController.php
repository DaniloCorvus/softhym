<?php

namespace App\Http\Controllers;

use App\Models\DevolucionTransferencia;
use Illuminate\Http\Request;

class DevolucionTransferenciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DevolucionTransferencia  $devolucionTransferencia
     * @return \Illuminate\Http\Response
     */
    public function show(DevolucionTransferencia $devolucionTransferencia)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DevolucionTransferencia  $devolucionTransferencia
     * @return \Illuminate\Http\Response
     */
    public function edit(DevolucionTransferencia $devolucionTransferencia)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DevolucionTransferencia  $devolucionTransferencia
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DevolucionTransferencia $devolucionTransferencia)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DevolucionTransferencia  $devolucionTransferencia
     * @return \Illuminate\Http\Response
     */
    public function destroy(DevolucionTransferencia $devolucionTransferencia)
    {
        //
    }
}
