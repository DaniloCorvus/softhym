<?php

namespace App\Http\Controllers;

use App\Models\CuentaSaldo;
use Illuminate\Http\Request;

class CuentaSaldoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CuentaSaldo  $cuentaSaldo
     * @return \Illuminate\Http\Response
     */
    public function show(CuentaSaldo $cuentaSaldo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CuentaSaldo  $cuentaSaldo
     * @return \Illuminate\Http\Response
     */
    public function edit(CuentaSaldo $cuentaSaldo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CuentaSaldo  $cuentaSaldo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CuentaSaldo $cuentaSaldo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CuentaSaldo  $cuentaSaldo
     * @return \Illuminate\Http\Response
     */
    public function destroy(CuentaSaldo $cuentaSaldo)
    {
        //
    }
}
