<?php

namespace App\Http\Controllers;

use App\Models\DiarioCuenta;
use Illuminate\Http\Request;

class DiarioCuentaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DiarioCuenta  $diarioCuenta
     * @return \Illuminate\Http\Response
     */
    public function show(DiarioCuenta $diarioCuenta)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DiarioCuenta  $diarioCuenta
     * @return \Illuminate\Http\Response
     */
    public function edit(DiarioCuenta $diarioCuenta)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DiarioCuenta  $diarioCuenta
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DiarioCuenta $diarioCuenta)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DiarioCuenta  $diarioCuenta
     * @return \Illuminate\Http\Response
     */
    public function destroy(DiarioCuenta $diarioCuenta)
    {
        //
    }
}
