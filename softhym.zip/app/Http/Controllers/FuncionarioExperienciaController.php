<?php

namespace App\Http\Controllers;

use App\Models\FuncionarioExperiencia;
use Illuminate\Http\Request;

class FuncionarioExperienciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\FuncionarioExperiencia  $funcionarioExperiencia
     * @return \Illuminate\Http\Response
     */
    public function show(FuncionarioExperiencia $funcionarioExperiencia)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\FuncionarioExperiencia  $funcionarioExperiencia
     * @return \Illuminate\Http\Response
     */
    public function edit(FuncionarioExperiencia $funcionarioExperiencia)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\FuncionarioExperiencia  $funcionarioExperiencia
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FuncionarioExperiencia $funcionarioExperiencia)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\FuncionarioExperiencia  $funcionarioExperiencia
     * @return \Illuminate\Http\Response
     */
    public function destroy(FuncionarioExperiencia $funcionarioExperiencia)
    {
        //
    }
}
