<?php

namespace App\Http\Controllers;

use App\Models\MonedaCampo;
use Illuminate\Http\Request;

class MonedaCampoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MonedaCampo  $monedaCampo
     * @return \Illuminate\Http\Response
     */
    public function show(MonedaCampo $monedaCampo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MonedaCampo  $monedaCampo
     * @return \Illuminate\Http\Response
     */
    public function edit(MonedaCampo $monedaCampo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MonedaCampo  $monedaCampo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MonedaCampo $monedaCampo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MonedaCampo  $monedaCampo
     * @return \Illuminate\Http\Response
     */
    public function destroy(MonedaCampo $monedaCampo)
    {
        //
    }
}
