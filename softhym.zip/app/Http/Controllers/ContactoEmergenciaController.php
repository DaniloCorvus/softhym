<?php

namespace App\Http\Controllers;

use App\Models\ContactoEmergencia;
use Illuminate\Http\Request;

class ContactoEmergenciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ContactoEmergencia  $contactoEmergencia
     * @return \Illuminate\Http\Response
     */
    public function show(ContactoEmergencia $contactoEmergencia)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ContactoEmergencia  $contactoEmergencia
     * @return \Illuminate\Http\Response
     */
    public function edit(ContactoEmergencia $contactoEmergencia)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ContactoEmergencia  $contactoEmergencia
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ContactoEmergencia $contactoEmergencia)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ContactoEmergencia  $contactoEmergencia
     * @return \Illuminate\Http\Response
     */
    public function destroy(ContactoEmergencia $contactoEmergencia)
    {
        //
    }
}
