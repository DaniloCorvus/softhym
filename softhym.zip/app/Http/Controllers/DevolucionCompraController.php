<?php

namespace App\Http\Controllers;

use App\Models\DevolucionCompra;
use Illuminate\Http\Request;

class DevolucionCompraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DevolucionCompra  $devolucionCompra
     * @return \Illuminate\Http\Response
     */
    public function show(DevolucionCompra $devolucionCompra)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DevolucionCompra  $devolucionCompra
     * @return \Illuminate\Http\Response
     */
    public function edit(DevolucionCompra $devolucionCompra)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DevolucionCompra  $devolucionCompra
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DevolucionCompra $devolucionCompra)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DevolucionCompra  $devolucionCompra
     * @return \Illuminate\Http\Response
     */
    public function destroy(DevolucionCompra $devolucionCompra)
    {
        //
    }
}
