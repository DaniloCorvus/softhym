<?php

namespace App\Http\Controllers;

use App\Models\Tipocuenta;
use Illuminate\Http\Request;

class TipocuentaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Tipocuenta  $tipocuenta
     * @return \Illuminate\Http\Response
     */
    public function show(Tipocuenta $tipocuenta)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Tipocuenta  $tipocuenta
     * @return \Illuminate\Http\Response
     */
    public function edit(Tipocuenta $tipocuenta)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Tipocuenta  $tipocuenta
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tipocuenta $tipocuenta)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Tipocuenta  $tipocuenta
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tipocuenta $tipocuenta)
    {
        //
    }
}
